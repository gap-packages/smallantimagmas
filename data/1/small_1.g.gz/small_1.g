local result;result:=[];return result;
