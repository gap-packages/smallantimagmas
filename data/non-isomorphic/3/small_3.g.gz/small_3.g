local result;result:=[
757,
1486,
7732,
784,
13,
9976,
9652,
9544,
715,
5299
];return result;
